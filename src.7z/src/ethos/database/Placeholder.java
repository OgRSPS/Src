package ethos.database;

public class Placeholder {

}
