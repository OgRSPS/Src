package ethos.util;

import java.io.FileReader;
import java.nio.file.Paths;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.stream.JsonReader;

/**
 * The utility class that provides functions for parsing {@code .json} files.
 * 
 * @author lare96 <http://www.rune-server.org/members/lare96/>
 */
public abstract class JsonLoader {

    /**
	 * The path to the {@code .json} file being parsed.
	 */
	private final String path;

	/**
	 * Creates a new {@link JsonLoader}.
	 * 
	 * @param path
	 *            the path to the {@code .json} file being parsed.
	 */
	public JsonLoader(String path) {
		this.path = path;
	}

    /**
	 * A dynamic method that allows the user to read and modify the parsed data.
	 * 
	 * @param reader
	 *            the reader for retrieving the parsed data.
	 * @param builder
	 *            the builder for retrieving the parsed data.
	 */
	public abstract void load(JsonObject reader, Gson builder);

    /**
	 * Loads the parsed data. How the data is loaded is defined by
	 * {@link JsonLoader#load(JsonObject, Gson)}.
	 * 
	 * @return the loader instance, for chaining.
	 */
	public final JsonLoader load() {
		try (JsonReader jsonReader = new JsonReader(new FileReader(Paths.get(path).toFile()))) {
            jsonReader.setLenient(true);
            Gson builder = new GsonBuilder().create();
            JsonArray array = builder.fromJson(jsonReader, JsonArray.class);
            for (int i = 0; i < array.size(); i++) {
                JsonObject reader = (JsonObject) array.get(i);
                load(reader, builder);
            }
		} catch (Exception e) {
			e.printStackTrace();
        }
        return this;
    }
}
